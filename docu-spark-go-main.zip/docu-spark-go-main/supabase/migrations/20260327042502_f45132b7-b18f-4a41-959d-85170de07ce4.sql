
INSERT INTO storage.buckets (id, name, public) VALUES ('settings', 'settings', true);

CREATE POLICY "Anyone can read settings files"
ON storage.objects FOR SELECT
TO authenticated
USING (bucket_id = 'settings');

CREATE POLICY "Authenticated users can upload settings files"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (bucket_id = 'settings');

CREATE POLICY "Authenticated users can update settings files"
ON storage.objects FOR UPDATE
TO authenticated
USING (bucket_id = 'settings');

CREATE POLICY "Authenticated users can delete settings files"
ON storage.objects FOR DELETE
TO authenticated
USING (bucket_id = 'settings');
