
CREATE TABLE public.categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL UNIQUE,
  created_at timestamp with time zone NOT NULL DEFAULT now()
);

CREATE TABLE public.units (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL UNIQUE,
  created_at timestamp with time zone NOT NULL DEFAULT now()
);

ALTER TABLE public.categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.units ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can read categories" ON public.categories FOR SELECT TO authenticated USING (true);
CREATE POLICY "Authenticated users can insert categories" ON public.categories FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "Authenticated users can update categories" ON public.categories FOR UPDATE TO authenticated USING (true);
CREATE POLICY "Authenticated users can delete categories" ON public.categories FOR DELETE TO authenticated USING (true);

CREATE POLICY "Authenticated users can read units" ON public.units FOR SELECT TO authenticated USING (true);
CREATE POLICY "Authenticated users can insert units" ON public.units FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "Authenticated users can update units" ON public.units FOR UPDATE TO authenticated USING (true);
CREATE POLICY "Authenticated users can delete units" ON public.units FOR DELETE TO authenticated USING (true);

INSERT INTO public.categories (name) VALUES
('Processo Administrativo'),('Ofício'),('Parecer Jurídico'),('Parecer Técnico'),
('Nota Fiscal'),('Contrato'),('Termo Aditivo'),('Edital'),('Termo de Referência'),
('ETP'),('Pesquisa de Preços'),('Empenho'),('Relatório'),('Portaria'),('Decreto'),
('Ata'),('Certidão'),('Laudo Técnico');

INSERT INTO public.units (name) VALUES
('Licitações'),('Compras'),('Contratos'),('Patrimônio'),('Protocolo'),('Arquivo'),
('Jurídico'),('Controladoria'),('Contabilidade'),('Tesouraria'),('Recursos Humanos'),
('Administração'),('Finanças'),('Convênios'),('Engenharia'),('Saúde'),('Educação'),
('Assistência Social'),('Obras'),('Tributação');
